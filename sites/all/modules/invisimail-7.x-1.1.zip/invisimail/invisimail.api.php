<?php
// $Id: invisimail.api.php,v 1.1.2.1 2010/11/18 22:36:56 crell Exp $

/**
 * Defines encoders available to invisimail to get turned into formatters.
 */
function hook_invisimail_encoder_info() {

}

/**
 * Allows modules to alter the encoder definitions provided by other modules.
 */
function hook_invisimail_encoder_info_alter(&$encoders) {

}